#include "utilis.h"
#include "scheduler.h"
#include "interrupt.h"
#include "tlb.h"
#include "trap.h"
#include "syscall.h"

//Processi di test
extern void test1();
extern void test2();
extern void test3();

int main(){
	
	//Inizializzazione delle new area
	init_interrupt();
	init_syscall();
	init_tlb();
	init_pgmtrap();
	
	
	//Inizializzazione processi
	initPcbs();
	//Inizializzazione ready queue
	initScheduler();
	
	//Aggiunta processi nella ready queue
	
	initProcess(1,(memaddr)test1);
	initProcess(2,(memaddr)test2);
	initProcess(3,(memaddr)test3);
	
	scheduler();
	HALT();
	
	return(0);
}
