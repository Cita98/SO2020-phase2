Laboratorio di Sistemi Operativi 

	PHASE 1

Gestione delle code: Livello 2

Setup 


- Installa uMPS (https://github.com/tjonjic/umps)

- Segui le istruzioni per installare uARM
  https://github.com/mellotanica/uARM

- Entra nella cartella che contiene i file

- Per compilare su uarm lancia il comando 
	make uarm 

- Apri uarm e setta il kernel.core, file che comparirà all'interno della cartella, in seguito al make

- Avvia la macchina 
	- Clicca sul bottone di accensione rosso in alto a sinistra
	- Clicca sul bottone verde play accanto al precedente

- Apri il terminale
	- Terminals
	- Terminal 0

- Per compilare su umps lancia il comando 
	make umps

- Lancia umps2 e setta il kernel.core

- Avvia la macchina
	- Seleziona scheda "machine"
	- Power on 

- Apri il terminale 
	- Seleziona scheda "windows"
	- Terminal 0


Componenti gruppo
- Accorsi Martina 
- Bretta Luca
- Mazzocato Luca
