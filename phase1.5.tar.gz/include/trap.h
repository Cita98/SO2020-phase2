#ifndef _TRAP_H
#define _TRAP_H

#include "const.h"
#include "types_bikaya.h"
#include "handler.h"

void init_pgmtrap(); //Inizializzazione pgmtrap

#endif