#ifndef _CONSTUMPS_H
#define _CONSTUMPS_H

#include "umps/libumps.h"
#include "umps/arch.h"
#include "umps/types.h"
#include "umps/cp0.h"

/* Utili */
#define CAUSE_IP_GET(cause, int_no) ((cause) & (1 << ((int_no) + 8)))

/* Costanti */
 #define FRAMESIZE 				4096

//Rinominazione per unificare i nomi nelle due architetture
#define prog_counter 		pc_epc
#define stack_pointer 		reg_sp

/* Indirizzi old e new areas */
#define INT_NEWAREA 		0x2000008c
#define INT_OLDAREA 		0x20000000
#define TLB_NEWAREA 		0x200001a4
#define TLB_OLDAREA 		0x20000118
#define PGMTRAP_NEWAREA 	0x200002bc
#define PGMTRAP_OLDAREA 	0x20000230
#define SYSCALL_NEWAREA 	0x200003d4
#define SYSCALL_OLDAREA 	0x20000348


#endif