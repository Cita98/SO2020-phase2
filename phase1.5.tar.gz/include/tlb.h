#ifndef _TLB_H
#define _TLB_H

#include "const.h"
#include "types_bikaya.h"
#include "handler.h"

void init_tlb(); //Inizializzazione tlb 

#endif